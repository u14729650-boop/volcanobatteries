import { motion } from "motion/react";
import {
  CheckCircle,
  Shield,
  Clock,
  ThumbsUp,
  Users,
  Award,
  TrendingUp,
  Heart,
  Wrench,
  Phone,
} from "lucide-react";

export function WhyChooseUs() {
  const reasons = [
    {
      icon: CheckCircle,
      title: "Genuine Products Only",
      desc: "We source all our batteries directly from authorized distributors and manufacturers. Every product is 100% genuine with proper documentation and serial numbers.",
    },
    {
      icon: Shield,
      title: "Warranty-Backed Quality",
      desc: "All batteries come with comprehensive manufacturer warranty. We provide full support for warranty claims and replacements throughout the coverage period.",
    },
    {
      icon: Clock,
      title: "Fast & Efficient Service",
      desc: "We value your time. Most battery replacements are completed within 30 minutes. Home service available across Surat with no extra waiting time.",
    },
    {
      icon: Users,
      title: "Expert Technicians",
      desc: "Our team consists of trained and experienced professionals who understand all vehicle types. From standard cars to luxury German vehicles, we've got you covered.",
    },
    {
      icon: Award,
      title: "10+ Years Experience",
      desc: "Over a decade of serving Surat's automotive community. Our experience helps us recommend the perfect battery for your specific vehicle and usage pattern.",
    },
    {
      icon: TrendingUp,
      title: "Competitive Pricing",
      desc: "Get the best value for your money with our transparent pricing. No hidden charges, no surprises. Just honest pricing for quality products and services.",
    },
    {
      icon: Heart,
      title: "Customer-Centric Approach",
      desc: "Your satisfaction is our priority. We build long-term relationships through honest advice, quality service, and reliable after-sales support.",
    },
    {
      icon: Wrench,
      title: "Complete Installation",
      desc: "Professional installation included with proper testing, terminal cleaning, and safety checks. We ensure your new battery performs optimally from day one.",
    },
  ];

  const testimonials = [
    {
      name: "Rajesh Patel",
      vehicle: "Honda City",
      rating: 5,
      text: "Excellent service! They came to my home, replaced the battery in 20 minutes, and the pricing was very reasonable. Highly recommended!",
    },
    {
      name: "Priya Shah",
      vehicle: "Activa 125",
      rating: 5,
      text: "Very professional team. They helped me choose the right battery for my scooter and explained the warranty details clearly. Great experience!",
    },
    {
      name: "Amit Desai",
      vehicle: "Mercedes E-Class",
      rating: 5,
      text: "As a luxury car owner, I was worried about the battery quality. Volcano Batteries provided genuine Bosch battery with proper documentation. Very satisfied!",
    },
  ];

  const stats = [
    { number: "10+", label: "Years in Business" },
    { number: "5000+", label: "Happy Customers" },
    { number: "15+", label: "Battery Brands" },
    { number: "100+", label: "Service Areas" },
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-black to-gray-900 text-white py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-3xl"
          >
            <h1 className="font-bold text-4xl sm:text-5xl mb-6">
              Why Choose <span className="text-red-600">Volcano Batteries?</span>
            </h1>
            <p className="text-lg text-gray-300 leading-relaxed">
              Discover what makes us Surat's most trusted automotive battery service provider. Quality, reliability, and customer satisfaction are at the heart of everything we do.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-red-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.1 }}
                viewport={{ once: true }}
                className="text-center"
              >
                <div className="font-bold text-4xl sm:text-5xl mb-2">{stat.number}</div>
                <div className="text-red-100">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Main Reasons */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="font-bold text-3xl sm:text-4xl mb-4">
              What Sets Us <span className="text-red-600">Apart</span>
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Here's why thousands of customers trust Volcano Batteries for their automotive battery needs
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {reasons.map((reason, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                viewport={{ once: true }}
                className="bg-gradient-to-br from-gray-50 to-white border-2 border-gray-200 p-6 rounded-xl hover:border-red-600 transition-all hover:shadow-lg"
              >
                <div className="flex items-start gap-4">
                  <div className="bg-red-600 w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0">
                    <reason.icon className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="font-bold text-xl mb-2">{reason.title}</h3>
                    <p className="text-gray-600">{reason.desc}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="font-bold text-3xl sm:text-4xl mb-4">
              What Our <span className="text-red-600">Customers Say</span>
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Don't just take our word for it - hear from satisfied customers
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.15 }}
                viewport={{ once: true }}
                className="bg-white p-6 rounded-xl shadow-lg"
              >
                <div className="flex gap-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <span key={i} className="text-yellow-400 text-xl">★</span>
                  ))}
                </div>
                <p className="text-gray-600 mb-4 italic">"{testimonial.text}"</p>
                <div className="border-t pt-4">
                  <p className="font-bold">{testimonial.name}</p>
                  <p className="text-sm text-gray-500">{testimonial.vehicle}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Service Guarantee */}
      <section className="py-16 bg-black text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="font-bold text-3xl sm:text-4xl mb-6">
                Our <span className="text-red-600">Commitment</span> to You
              </h2>
              <div className="space-y-4">
                {[
                  "Only genuine products from authorized sources",
                  "Transparent pricing with no hidden charges",
                  "Professional installation by trained technicians",
                  "Full warranty support and after-sales service",
                  "Free battery health check for all customers",
                  "Home service available across Surat",
                  "Quick response time - we value your time",
                  "Expert advice on battery selection",
                ].map((item, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.05 }}
                    viewport={{ once: true }}
                    className="flex items-center gap-3"
                  >
                    <CheckCircle className="w-5 h-5 text-red-600 flex-shrink-0" />
                    <span>{item}</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="bg-gradient-to-br from-red-600 to-red-800 p-8 rounded-xl"
            >
              <ThumbsUp className="w-16 h-16 mb-6" />
              <h3 className="font-bold text-2xl mb-4">100% Satisfaction Guarantee</h3>
              <p className="text-red-100 mb-6 leading-relaxed">
                We stand behind the quality of our products and services. If you're not completely satisfied, we'll make it right. Your trust is our most valuable asset.
              </p>
              <p className="text-red-100 leading-relaxed">
                Our goal is not just to sell you a battery, but to build a long-term relationship based on trust, quality, and reliable service.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-red-600 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Phone className="w-16 h-16 mx-auto mb-6" />
          <h2 className="font-bold text-3xl sm:text-4xl mb-4">
            Experience the Volcano Difference
          </h2>
          <p className="text-lg mb-8 text-red-100">
            Join thousands of satisfied customers. Contact us today for the best battery service in Surat!
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="tel:9429149149"
              className="bg-white hover:bg-gray-100 text-red-600 px-8 py-4 rounded-lg font-bold transition-all"
            >
              Call: 9429149149
            </a>
            <a
              href="tel:9825445979"
              className="bg-black hover:bg-gray-900 text-white px-8 py-4 rounded-lg font-bold transition-all"
            >
              Call: 9825445979
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
