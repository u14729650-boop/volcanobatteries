import { motion } from "motion/react";
import { CheckCircle, Star, Shield, Zap } from "lucide-react";

export function Products() {
  const brands = [
    { name: "Amaron", popular: true },
    { name: "Exide", popular: true },
    { name: "Powerzone", popular: true },
  ];

  const batteryTypes = [
    {
      title: "Conventional Batteries",
      desc: "Traditional lead-acid batteries suitable for most standard vehicles",
      features: [
        "Cost-effective solution",
        "Reliable performance",
        "Wide compatibility",
        "Easy maintenance",
      ],
    },
    {
      title: "Maintenance-Free Batteries",
      desc: "Sealed batteries that require no water topping or regular maintenance",
      features: [
        "Zero maintenance required",
        "Longer lifespan",
        "Spill-proof design",
        "Better performance",
      ],
    },
    {
      title: "Calcium Batteries",
      desc: "Advanced batteries with calcium alloy for enhanced performance",
      features: [
        "Low self-discharge",
        "Extended durability",
        "High cranking power",
        "Temperature resistant",
      ],
    },
    {
      title: "AGM Batteries",
      desc: "Premium Absorbent Glass Mat batteries for luxury and high-performance vehicles",
      features: [
        "Superior performance",
        "Vibration resistant",
        "Deep cycle capability",
        "Ideal for luxury cars",
      ],
    },
    {
      title: "Inverter/UPS Battery",
      desc: "Deep cycle batteries designed for home inverters and UPS systems",
      features: [
        "Long backup time",
        "Deep discharge capability",
        "Extended cycle life",
        "Perfect for power backup",
      ],
    },
    {
      title: "Generator Battery",
      desc: "Heavy-duty batteries for generators and industrial applications",
      features: [
        "High starting power",
        "Rugged construction",
        "Reliable performance",
        "Designed for heavy loads",
      ],
    },
  ];

  const vehicleCategories = [
    {
      category: "Passenger Cars",
      models: "All hatchbacks, sedans, SUVs, and MPVs",
      capacity: "35Ah - 80Ah",
      brands: "Amaron, Exide, Powerzone",
    },
    {
      category: "Motorcycles",
      models: "All two-wheelers and scooters",
      capacity: "3Ah - 12Ah",
      brands: "Amaron, Exide, Powerzone",
    },
    {
      category: "Commercial Vehicles",
      models: "Trucks, buses, and fleet vehicles",
      capacity: "88Ah - 180Ah",
      brands: "Amaron, Exide, Powerzone",
    },
    {
      category: "Luxury Cars",
      models: "BMW, Mercedes, Audi, Jaguar",
      capacity: "70Ah - 105Ah",
      brands: "Amaron, Exide, Powerzone",
    },
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-black to-gray-900 text-white py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-3xl"
          >
            <h1 className="font-bold text-4xl sm:text-5xl mb-6">
              Our <span className="text-red-600">Products</span>
            </h1>
            <p className="text-lg text-gray-300 leading-relaxed">
              Wide range of genuine automotive batteries from trusted brands. Find the perfect battery for your vehicle with warranty coverage.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Brands We Offer */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="font-bold text-3xl sm:text-4xl mb-4">
              Trusted <span className="text-red-600">Brands</span>
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              We stock batteries from India's leading manufacturers
            </p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {brands.map((brand, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.05 }}
                viewport={{ once: true }}
                className={`bg-gradient-to-br from-gray-50 to-white border-2 p-6 rounded-xl text-center hover:border-red-600 transition-all hover:shadow-lg relative ${
                  brand.popular ? "border-red-600" : "border-gray-200"
                }`}
              >
                {brand.popular && (
                  <div className="absolute top-2 right-2">
                    <Star className="w-4 h-4 text-red-600 fill-red-600" />
                  </div>
                )}
                <h3 className="font-bold text-lg">{brand.name}</h3>
                {brand.popular && (
                  <p className="text-xs text-red-600 mt-1">Popular</p>
                )}
              </motion.div>
            ))}
          </div>

          <div className="mt-8 text-center">
            <p className="text-gray-600 text-sm">
              <Star className="w-4 h-4 inline text-red-600 fill-red-600" /> = Most Popular Brands
            </p>
          </div>
        </div>
      </section>

      {/* Battery Types */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="font-bold text-3xl sm:text-4xl mb-4">
              Battery <span className="text-red-600">Types</span>
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Different types of batteries to suit your vehicle's needs
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {batteryTypes.map((type, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                viewport={{ once: true }}
                className="bg-white p-6 rounded-xl shadow-lg border-2 border-gray-200 hover:border-red-600 transition-all"
              >
                <div className="flex items-start gap-4 mb-4">
                  <div className="bg-red-600 w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Zap className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="font-bold text-xl mb-2">{type.title}</h3>
                    <p className="text-gray-600 text-sm">{type.desc}</p>
                  </div>
                </div>
                <ul className="space-y-2 ml-16">
                  {type.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center gap-2 text-sm text-gray-700">
                      <CheckCircle className="w-4 h-4 text-red-600 flex-shrink-0" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Vehicle Categories */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="font-bold text-3xl sm:text-4xl mb-4">
              Batteries by <span className="text-red-600">Vehicle Type</span>
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Find the right battery for your vehicle
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {vehicleCategories.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                viewport={{ once: true }}
                className="bg-gradient-to-br from-gray-50 to-white p-6 rounded-xl border-2 border-gray-200 hover:border-red-600 transition-all"
              >
                <h3 className="font-bold text-xl mb-4 text-red-600">
                  {item.category}
                </h3>
                <div className="space-y-3">
                  <div>
                    <p className="text-sm font-semibold text-gray-700">Vehicle Models:</p>
                    <p className="text-gray-600">{item.models}</p>
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-gray-700">Capacity Range:</p>
                    <p className="text-gray-600">{item.capacity}</p>
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-gray-700">Available Brands:</p>
                    <p className="text-gray-600">{item.brands}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Product Features */}
      <section className="py-16 bg-black text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="font-bold text-3xl sm:text-4xl mb-4">
              Why Our <span className="text-red-600">Products?</span>
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center"
            >
              <div className="bg-red-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-8 h-8 text-white" />
              </div>
              <h3 className="font-bold text-xl mb-3">100% Genuine</h3>
              <p className="text-gray-300">
                All batteries are sourced directly from authorized distributors. No duplicates or refurbished products.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              viewport={{ once: true }}
              className="text-center"
            >
              <div className="bg-red-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="w-8 h-8 text-white" />
              </div>
              <h3 className="font-bold text-xl mb-3">Warranty Coverage</h3>
              <p className="text-gray-300">
                Every battery comes with manufacturer warranty. Duration varies by model and brand chosen.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              viewport={{ once: true }}
              className="text-center"
            >
              <div className="bg-red-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Star className="w-8 h-8 text-white" />
              </div>
              <h3 className="font-bold text-xl mb-3">Best Prices</h3>
              <p className="text-gray-300">
                Competitive pricing with no hidden charges. Get the best value for your investment.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Warranty Info */}
      <section className="py-16 bg-red-600 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <Shield className="w-16 h-16 mx-auto mb-6" />
            <h2 className="font-bold text-3xl sm:text-4xl mb-4">
              Warranty Information
            </h2>
            <p className="text-lg text-red-100 mb-6 leading-relaxed">
              All batteries sold by Volcano Batteries come with manufacturer warranty. The warranty period depends on the battery model and brand you choose. Typical warranty ranges from 12 to 72 months.
            </p>
            <p className="text-red-100 mb-8">
              We provide full warranty support and will assist you with any warranty claims throughout the coverage period.
            </p>
            <a
              href="tel:9429149149"
              className="inline-block bg-white hover:bg-gray-100 text-red-600 px-8 py-4 rounded-lg font-bold transition-all"
            >
              Call for More Details
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}