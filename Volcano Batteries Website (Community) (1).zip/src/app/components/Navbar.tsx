import { useState } from "react";
import { Link, useLocation } from "react-router";
import { Menu, X, Zap } from "lucide-react";

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  const navLinks = [
    { name: "Home", path: "/" },
    { name: "About", path: "/about" },
    { name: "Services", path: "/services" },
    { name: "Products", path: "/products" },
    { name: "Why Choose Us", path: "/why-choose-us" },
    { name: "Contact", path: "/contact" },
  ];

  const isActive = (path: string) => {
    if (path === "/") {
      return location.pathname === "/";
    }
    return location.pathname.startsWith(path);
  };

  return (
    <nav className="bg-black text-white sticky top-0 z-50 shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 group">
            <div className="bg-red-600 p-2 rounded-lg group-hover:bg-red-700 transition-colors">
              <Zap className="w-6 h-6 sm:w-8 sm:h-8" />
            </div>
            <div>
              <h1 className="font-bold text-lg sm:text-xl">VOLCANO</h1>
              <p className="text-xs text-red-600 -mt-1">BATTERIES</p>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center gap-8">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`hover:text-red-600 transition-colors font-medium ${
                  isActive(link.path) ? "text-red-600" : ""
                }`}
              >
                {link.name}
              </Link>
            ))}
            <a
              href="tel:9429149149"
              className="bg-red-600 hover:bg-red-700 px-6 py-3 rounded-lg font-bold transition-colors"
            >
              Call Now
            </a>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="lg:hidden p-2 hover:bg-white/10 rounded-lg transition-colors"
          >
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <div className="lg:hidden pb-6 space-y-4">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                onClick={() => setIsOpen(false)}
                className={`block py-2 hover:text-red-600 transition-colors font-medium ${
                  isActive(link.path) ? "text-red-600" : ""
                }`}
              >
                {link.name}
              </Link>
            ))}
            <a
              href="tel:9429149149"
              className="block text-center bg-red-600 hover:bg-red-700 px-6 py-3 rounded-lg font-bold transition-colors"
            >
              Call Now
            </a>
          </div>
        )}
      </div>
    </nav>
  );
}
