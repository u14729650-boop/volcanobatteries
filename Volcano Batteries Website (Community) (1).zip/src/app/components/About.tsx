import { motion } from "motion/react";
import { Users, Target, Award, Heart } from "lucide-react";

export function About() {
  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-black to-gray-900 text-white py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-3xl"
          >
            <h1 className="font-bold text-4xl sm:text-5xl mb-6">
              About <span className="text-red-600">Volcano Batteries</span>
            </h1>
            <p className="text-lg text-gray-300 leading-relaxed">
              Your trusted partner for automotive battery solutions in Surat, Gujarat. We've been powering vehicles with reliable, high-quality batteries and exceptional service.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="font-bold text-3xl sm:text-4xl mb-6">
                Our <span className="text-red-600">Story</span>
              </h2>
              <p className="text-gray-600 mb-4 leading-relaxed">
                Volcano Batteries has been serving Surat's automotive community with passion and dedication. We understand that a reliable battery is crucial for your vehicle's performance, and we're committed to providing only the best products and services.
              </p>
              <p className="text-gray-600 mb-4 leading-relaxed">
                Our team of experienced technicians brings expertise in all types of automotive batteries - from compact cars to heavy-duty trucks, and from everyday vehicles to luxury German cars.
              </p>
              <p className="text-gray-600 leading-relaxed">
                We pride ourselves on offering genuine products, transparent pricing, and unmatched customer service that has earned us the trust of thousands of satisfied customers across Surat.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="grid grid-cols-2 gap-6"
            >
              {[
                { icon: Users, title: "Expert Team", desc: "Skilled professionals" },
                { icon: Target, title: "Customer Focus", desc: "Your satisfaction first" },
                { icon: Award, title: "Quality Products", desc: "Genuine batteries only" },
                { icon: Heart, title: "Trusted Service", desc: "Reliable & honest" },
              ].map((item, index) => (
                <div
                  key={index}
                  className="bg-gradient-to-br from-gray-50 to-white border-2 border-gray-200 p-6 rounded-xl text-center hover:border-red-600 transition-all"
                >
                  <div className="bg-red-600 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4">
                    <item.icon className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="font-bold mb-2">{item.title}</h3>
                  <p className="text-sm text-gray-600">{item.desc}</p>
                </div>
              ))}
            </motion.div>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="bg-white p-8 rounded-xl shadow-lg border-l-4 border-red-600"
            >
              <div className="bg-red-600 w-16 h-16 rounded-full flex items-center justify-center mb-6">
                <Target className="w-8 h-8 text-white" />
              </div>
              <h3 className="font-bold text-2xl mb-4">Our Mission</h3>
              <p className="text-gray-600 leading-relaxed">
                To provide Surat's vehicle owners with top-quality automotive batteries and exceptional service, ensuring every customer drives away with complete confidence and satisfaction. We aim to be the first choice for battery solutions in the region.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              viewport={{ once: true }}
              className="bg-black text-white p-8 rounded-xl shadow-lg border-l-4 border-red-600"
            >
              <div className="bg-red-600 w-16 h-16 rounded-full flex items-center justify-center mb-6">
                <Award className="w-8 h-8 text-white" />
              </div>
              <h3 className="font-bold text-2xl mb-4">Our Vision</h3>
              <p className="text-gray-300 leading-relaxed">
                To become the most trusted and recognized automotive battery service provider in Gujarat, known for our integrity, quality products, and customer-centric approach. We envision a future where every vehicle owner knows they can rely on Volcano Batteries.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="font-bold text-3xl sm:text-4xl mb-4">
              Our <span className="text-red-600">Core Values</span>
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              The principles that guide everything we do
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                title: "Quality First",
                desc: "We never compromise on the quality of our products. Every battery we sell is genuine and meets the highest standards.",
              },
              {
                title: "Customer Trust",
                desc: "Building lasting relationships through transparency, honesty, and reliable service is at the heart of our business.",
              },
              {
                title: "Expert Knowledge",
                desc: "Our team stays updated with the latest automotive battery technology to provide you with the best advice and service.",
              },
              {
                title: "Fast Service",
                desc: "We value your time. Our efficient service ensures quick battery installation and replacement without compromising quality.",
              },
              {
                title: "Fair Pricing",
                desc: "Competitive and transparent pricing with no hidden charges. You get the best value for your investment.",
              },
              {
                title: "After-Sales Support",
                desc: "Our relationship doesn't end with the sale. We provide ongoing support and warranty service for complete peace of mind.",
              },
            ].map((value, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                viewport={{ once: true }}
                className="bg-gradient-to-br from-gray-50 to-white p-6 rounded-xl border-2 border-gray-200 hover:border-red-600 transition-all"
              >
                <div className="w-10 h-10 bg-red-600 rounded-lg flex items-center justify-center mb-4">
                  <span className="text-white font-bold">{index + 1}</span>
                </div>
                <h3 className="font-bold text-xl mb-3">{value.title}</h3>
                <p className="text-gray-600">{value.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
