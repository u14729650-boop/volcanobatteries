import { Link } from "react-router";
import { motion } from "motion/react";
import { Phone, Clock, Shield, MapPin, CheckCircle, Zap } from "lucide-react";

export function Home() {
  return (
    <div>
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-black via-gray-900 to-black text-white py-20 md:py-32 overflow-hidden">
        <div className="absolute inset-0 bg-red-600 opacity-10"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="max-w-3xl">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <div className="inline-flex items-center gap-2 bg-red-600/20 border border-red-600 rounded-full px-4 py-2 mb-6">
                <Zap className="w-4 h-4 text-red-600" />
                <span className="text-sm font-semibold">Trusted Battery Experts in Surat</span>
              </div>
              <h1 className="font-bold text-4xl sm:text-5xl lg:text-6xl mb-6 leading-tight">
                Power Your Journey with{" "}
                <span className="text-red-600">Premium Batteries</span>
              </h1>
              <p className="text-lg sm:text-xl text-gray-300 mb-8 leading-relaxed">
                Professional automotive battery service for cars, bikes, trucks & luxury vehicles. Fast installation, home service available, and warranty-backed quality.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <a
                  href="tel:9429149149"
                  className="bg-red-600 hover:bg-red-700 text-white px-8 py-4 rounded-lg font-bold transition-all hover:shadow-lg hover:shadow-red-600/50 flex items-center justify-center gap-2 text-lg"
                >
                  <Phone className="w-5 h-5" />
                  Call Now: 9429149149
                </a>
                <Link
                  to="/services"
                  className="bg-white hover:bg-gray-100 text-black px-8 py-4 rounded-lg font-bold transition-all flex items-center justify-center gap-2 text-lg"
                >
                  Our Services
                </Link>
              </div>
            </motion.div>
          </div>
        </div>

        {/* Decorative Elements */}
        <div className="absolute top-1/4 right-10 w-72 h-72 bg-red-600 rounded-full blur-3xl opacity-20"></div>
        <div className="absolute bottom-10 left-10 w-96 h-96 bg-red-600 rounded-full blur-3xl opacity-10"></div>
      </section>

      {/* Quick Features */}
      <section className="py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[
              { icon: Clock, title: "Home Service", desc: "We come to you" },
              { icon: Shield, title: "Warranty", desc: "Model-based warranty" },
              { icon: CheckCircle, title: "Genuine", desc: "100% authentic" },
              { icon: Zap, title: "Fast Service", desc: "Quick installation" },
            ].map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                viewport={{ once: true }}
                className="bg-gradient-to-br from-gray-50 to-white border-2 border-gray-200 p-6 rounded-xl text-center hover:border-red-600 transition-all hover:shadow-lg"
              >
                <div className="bg-red-600 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4">
                  <feature.icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-bold text-lg mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Overview */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="font-bold text-3xl sm:text-4xl mb-4">
              Our <span className="text-red-600">Services</span>
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Complete battery solutions for all types of vehicles
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                title: "Car Batteries",
                desc: "Premium batteries for all car models",
                emoji: "🚗",
              },
              {
                title: "Bike Batteries",
                desc: "Reliable power for motorcycles",
                emoji: "🏍️",
              },
              {
                title: "Truck Batteries",
                desc: "Heavy-duty batteries for trucks",
                emoji: "🚚",
              },
              {
                title: "Luxury Cars",
                desc: "Specialized for German & luxury vehicles",
                emoji: "🏎️",
              },
            ].map((service, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.1 }}
                viewport={{ once: true }}
                className="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-all border-2 border-transparent hover:border-red-600"
              >
                <div className="text-4xl mb-4">{service.emoji}</div>
                <h3 className="font-bold text-xl mb-2">{service.title}</h3>
                <p className="text-gray-600">{service.desc}</p>
              </motion.div>
            ))}
          </div>

          <div className="text-center mt-12">
            <Link
              to="/services"
              className="inline-block bg-red-600 hover:bg-red-700 text-white px-8 py-4 rounded-lg font-bold transition-all hover:shadow-lg"
            >
              View All Services
            </Link>
          </div>
        </div>
      </section>

      {/* Why Choose Us Preview */}
      <section className="py-16 bg-black text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="font-bold text-3xl sm:text-4xl mb-6">
                Why Choose <span className="text-red-600">Volcano Batteries?</span>
              </h2>
              <ul className="space-y-4">
                {[
                  "Wide range of genuine batteries",
                  "Expert installation & maintenance",
                  "Home service available across Surat",
                  "Competitive pricing",
                  "Model-specific warranty coverage",
                  "24/7 customer support",
                ].map((item, index) => (
                  <motion.li
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    viewport={{ once: true }}
                    className="flex items-center gap-3"
                  >
                    <CheckCircle className="w-5 h-5 text-red-600 flex-shrink-0" />
                    <span>{item}</span>
                  </motion.li>
                ))}
              </ul>
              <Link
                to="/why-choose-us"
                className="inline-block mt-8 bg-red-600 hover:bg-red-700 text-white px-8 py-4 rounded-lg font-bold transition-all"
              >
                Learn More
              </Link>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="grid grid-cols-2 gap-4"
            >
              {[
                { label: "Years Experience", value: "10+" },
                { label: "Happy Customers", value: "5000+" },
                { label: "Battery Brands", value: "15+" },
                { label: "Service Locations", value: "100+" },
              ].map((stat, index) => (
                <div
                  key={index}
                  className="bg-white/10 backdrop-blur-sm p-6 rounded-xl text-center border border-white/20"
                >
                  <div className="font-bold text-3xl text-red-600 mb-2">{stat.value}</div>
                  <div className="text-sm text-gray-300">{stat.label}</div>
                </div>
              ))}
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-red-600 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="font-bold text-3xl sm:text-4xl mb-4">
            Need a Battery Replacement?
          </h2>
          <p className="text-lg mb-8 text-red-100">
            Get expert service at your doorstep. Call us now or WhatsApp for instant assistance!
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="tel:9429149149"
              className="bg-white hover:bg-gray-100 text-red-600 px-8 py-4 rounded-lg font-bold transition-all flex items-center justify-center gap-2"
            >
              <Phone className="w-5 h-5" />
              9429149149
            </a>
            <a
              href="tel:9825445979"
              className="bg-black hover:bg-gray-900 text-white px-8 py-4 rounded-lg font-bold transition-all flex items-center justify-center gap-2"
            >
              <Phone className="w-5 h-5" />
              9825445979
            </a>
          </div>
          <div className="mt-8 flex items-center justify-center gap-2 text-red-100">
            <MapPin className="w-5 h-5" />
            <span>C-4 Near Amidhara Wadi, Beside Tapi Hospital, New Rander Road, Surat</span>
          </div>
        </div>
      </section>
    </div>
  );
}
