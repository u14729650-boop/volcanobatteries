import { motion } from "motion/react";
import {
  Car,
  Bike,
  Truck,
  Sparkles,
  Home,
  Wrench,
  Battery,
  Clock,
  Shield,
  CheckCircle,
} from "lucide-react";

export function Services() {
  const services = [
    {
      icon: Car,
      title: "Car Battery Service",
      desc: "Complete battery solutions for all car models including hatchbacks, sedans, SUVs, and MPVs.",
      features: [
        "All major brands available",
        "Free battery health check",
        "Professional installation",
        "Model-specific warranty",
      ],
    },
    {
      icon: Bike,
      title: "Bike Battery Service",
      desc: "Reliable batteries for motorcycles, scooters, and electric bikes with quick installation.",
      features: [
        "Two-wheeler specialists",
        "Genuine products only",
        "Same-day service",
        "Competitive pricing",
      ],
    },
    {
      icon: Truck,
      title: "Truck Battery Service",
      desc: "Heavy-duty batteries for commercial vehicles, trucks, and fleet vehicles.",
      features: [
        "High-capacity batteries",
        "Bulk orders welcome",
        "Fleet discounts",
        "Quick turnaround",
      ],
    },
    {
      icon: Sparkles,
      title: "Luxury & German Cars",
      desc: "Specialized service for luxury vehicles including BMW, Mercedes, Audi, and other premium brands.",
      features: [
        "Premium quality batteries",
        "Expert technicians",
        "Brand-specific solutions",
        "Extended warranty options",
      ],
    },
    {
      icon: Home,
      title: "Home Service",
      desc: "We come to your location for battery replacement and installation across Surat.",
      features: [
        "Doorstep service",
        "No extra charges",
        "All areas covered",
        "Call & we'll be there",
      ],
    },
    {
      icon: Wrench,
      title: "Battery Installation",
      desc: "Professional installation and replacement service with proper testing and setup.",
      features: [
        "Expert installation",
        "Safety checks included",
        "Post-installation testing",
        "Clean & efficient service",
      ],
    },
  ];

  const additionalServices = [
    {
      icon: Battery,
      title: "Battery Testing",
      desc: "Free battery health check to diagnose issues",
    },
    {
      icon: Wrench,
      title: "Terminal Cleaning",
      desc: "Clean and maintain battery terminals",
    },
    {
      icon: CheckCircle,
      title: "Old Battery Exchange",
      desc: "Exchange your old battery for best value",
    },
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-black to-gray-900 text-white py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-3xl"
          >
            <h1 className="font-bold text-4xl sm:text-5xl mb-6">
              Our <span className="text-red-600">Services</span>
            </h1>
            <p className="text-lg text-gray-300 leading-relaxed">
              Comprehensive automotive battery solutions for all vehicle types. Professional service, genuine products, and customer satisfaction guaranteed.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Main Services */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                viewport={{ once: true }}
                className="bg-gradient-to-br from-gray-50 to-white border-2 border-gray-200 p-6 rounded-xl hover:border-red-600 transition-all hover:shadow-lg"
              >
                <div className="bg-red-600 w-14 h-14 rounded-xl flex items-center justify-center mb-4">
                  <service.icon className="w-7 h-7 text-white" />
                </div>
                <h3 className="font-bold text-xl mb-3">{service.title}</h3>
                <p className="text-gray-600 mb-4">{service.desc}</p>
                <ul className="space-y-2">
                  {service.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center gap-2 text-sm text-gray-700">
                      <CheckCircle className="w-4 h-4 text-red-600 flex-shrink-0" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Additional Services */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="font-bold text-3xl sm:text-4xl mb-4">
              Additional <span className="text-red-600">Services</span>
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Complimentary services to keep your battery in top condition
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {additionalServices.map((service, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.1 }}
                viewport={{ once: true }}
                className="bg-white p-6 rounded-xl shadow-lg text-center"
              >
                <div className="bg-red-600 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4">
                  <service.icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-bold text-lg mb-2">{service.title}</h3>
                <p className="text-gray-600 text-sm">{service.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Service Process */}
      <section className="py-16 bg-black text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="font-bold text-3xl sm:text-4xl mb-4">
              How It <span className="text-red-600">Works</span>
            </h2>
            <p className="text-gray-300 max-w-2xl mx-auto">
              Simple and hassle-free process to get your battery serviced
            </p>
          </div>

          <div className="grid md:grid-cols-4 gap-8">
            {[
              { step: "1", title: "Contact Us", desc: "Call or WhatsApp us with your requirement" },
              { step: "2", title: "Get Quote", desc: "We'll provide the best price for your vehicle" },
              { step: "3", title: "Schedule Visit", desc: "Choose home service or visit our location" },
              { step: "4", title: "Installation", desc: "Expert installation with warranty" },
            ].map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.15 }}
                viewport={{ once: true }}
                className="text-center"
              >
                <div className="bg-red-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 font-bold text-2xl">
                  {item.step}
                </div>
                <h3 className="font-bold text-lg mb-2">{item.title}</h3>
                <p className="text-gray-400 text-sm">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Service Features */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="bg-gradient-to-br from-red-50 to-white p-8 rounded-xl border-2 border-red-200"
            >
              <Clock className="w-12 h-12 text-red-600 mb-4" />
              <h3 className="font-bold text-xl mb-3">Fast Service</h3>
              <p className="text-gray-600">
                Quick battery replacement and installation. Most services completed within 30 minutes.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              viewport={{ once: true }}
              className="bg-gradient-to-br from-red-50 to-white p-8 rounded-xl border-2 border-red-200"
            >
              <Shield className="w-12 h-12 text-red-600 mb-4" />
              <h3 className="font-bold text-xl mb-3">Warranty Coverage</h3>
              <p className="text-gray-600">
                All batteries come with manufacturer warranty. Coverage depends on the battery model chosen.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              viewport={{ once: true }}
              className="bg-gradient-to-br from-red-50 to-white p-8 rounded-xl border-2 border-red-200"
            >
              <Home className="w-12 h-12 text-red-600 mb-4" />
              <h3 className="font-bold text-xl mb-3">Home Service</h3>
              <p className="text-gray-600">
                Can't visit us? No problem! We'll come to your location anywhere in Surat.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-red-600 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="font-bold text-3xl sm:text-4xl mb-4">
            Ready to Get Started?
          </h2>
          <p className="text-lg mb-8 text-red-100">
            Contact us now for the best battery service in Surat
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="tel:9429149149"
              className="bg-white hover:bg-gray-100 text-red-600 px-8 py-4 rounded-lg font-bold transition-all"
            >
              Call: 9429149149
            </a>
            <a
              href="tel:9825445979"
              className="bg-black hover:bg-gray-900 text-white px-8 py-4 rounded-lg font-bold transition-all"
            >
              Call: 9825445979
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
