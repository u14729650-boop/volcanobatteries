
  # Volcano Batteries Website (Community)

  This is a code bundle for Volcano Batteries Website (Community). The original project is available at https://www.figma.com/design/ZRRaBOGtHr3uzXZ6UudSqx/Volcano-Batteries-Website--Community-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  